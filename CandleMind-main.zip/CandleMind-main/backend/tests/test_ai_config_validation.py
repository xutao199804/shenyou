import pytest

from backend.app.services import ai_config_validation as validation


@pytest.fixture(autouse=True)
def public_dns(monkeypatch):
    monkeypatch.setattr(
        validation.socket,
        "getaddrinfo",
        lambda host, port: [(2, 1, 6, "", ("93.184.216.34", 0))],
    )


def test_cloud_provider_uses_official_https_host():
    config = validation.validate_ai_config(
        name=" DeepSeek ",
        provider="DEEPSEEK",
        api_key="secret",
        base_url="https://api.deepseek.com/v1/",
        model_name="deepseek-chat",
    )

    assert config.name == "DeepSeek"
    assert config.base_url == "https://api.deepseek.com/v1"
    assert validation.validate_base_url("deepseek", "https://api.deepseek.com") == (
        "https://api.deepseek.com"
    )

    with pytest.raises(validation.AIConfigValidationError, match="官方"):
        validation.validate_base_url("deepseek", "https://example.com/v1")
    with pytest.raises(validation.AIConfigValidationError, match="HTTPS"):
        validation.validate_base_url("deepseek", "http://api.deepseek.com/v1")


def test_cloud_provider_accepts_official_host_with_clash_fake_ip(monkeypatch):
    monkeypatch.setattr(
        validation.socket,
        "getaddrinfo",
        lambda host, port: [(2, 1, 6, "", ("198.18.0.1", 0))],
    )

    assert validation.validate_base_url(
        "deepseek", "https://api.deepseek.com/v1"
    ) == "https://api.deepseek.com/v1"


@pytest.mark.parametrize(
    "url",
    [
        "https://api.deepseek.com.evil.example/v1",
        "https://user:password@api.deepseek.com/v1",
        "https://api.deepseek.com:8443/v1",
        "https://api.deepseek.com/v1?token=x",
        "https://api.deepseek.com/v1#fragment",
    ],
)
def test_cloud_provider_rejects_non_official_or_malformed_urls(url):
    with pytest.raises(validation.AIConfigValidationError):
        validation.validate_base_url("deepseek", url)


@pytest.mark.parametrize(
    "url",
    [
        "file:///etc/passwd",
        "http://user:password@localhost:4000/v1",
        "http://localhost:4000/v1?token=x",
        "http://169.254.169.254/latest/meta-data",
    ],
)
def test_rejects_dangerous_or_unapproved_urls(url):
    with pytest.raises(validation.AIConfigValidationError):
        validation.validate_base_url("litellm", url)


def test_local_and_gateway_hosts_are_allowed():
    assert validation.validate_base_url("ollama", "http://localhost:11434/v1")
    assert validation.validate_base_url("ollama", "http://192.168.1.20:11434/v1")
    assert validation.validate_base_url("custom", "http://10.10.0.5:8000/v1")
    assert validation.validate_base_url("custom", "https://llm.example.com/v1")

    assert validation.validate_base_url("litellm", "https://gateway.internal/v1")


@pytest.mark.parametrize(
    "url",
    [
        "http://169.254.169.254/latest/meta-data",
        "http://0.0.0.0:4000/v1",
        "http://224.0.0.1:4000/v1",
    ],
)
def test_local_providers_still_reject_special_networks(url):
    with pytest.raises(validation.AIConfigValidationError):
        validation.validate_base_url("custom", url)


def test_local_provider_rejects_hostname_resolving_to_special_network(monkeypatch):
    monkeypatch.setattr(
        validation.socket,
        "getaddrinfo",
        lambda host, port: [(2, 1, 6, "", ("169.254.169.254", 0))],
    )

    with pytest.raises(validation.AIConfigValidationError):
        validation.validate_base_url("custom", "https://gateway.example/v1")


def test_cloud_key_and_model_are_required_but_local_keys_are_optional():
    with pytest.raises(validation.AIConfigValidationError, match="API Key"):
        validation.validate_ai_config(
            name="OpenAI",
            provider="openai",
            api_key="",
            base_url=None,
            model_name="gpt-4o-mini",
        )

    config = validation.validate_ai_config(
        name="Ollama",
        provider="ollama",
        api_key=None,
        base_url=None,
        model_name=None,
    )
    assert config.api_key == ""
    assert config.model_name == "llama3"

    custom = validation.validate_ai_config(
        name="Local gateway",
        provider="custom",
        api_key=None,
        base_url="http://192.168.1.20:8000/v1",
        model_name="local-model",
    )
    assert custom.api_key == ""


def test_existing_key_is_reused_and_control_characters_are_rejected():
    config = validation.validate_ai_config(
        name="Saved",
        provider="openai",
        api_key="",
        existing_api_key="existing-secret",
        base_url=None,
        model_name="gpt-4o-mini",
    )
    assert config.api_key == "existing-secret"

    with pytest.raises(validation.AIConfigValidationError, match="模型"):
        validation.validate_ai_config(
            name="Bad",
            provider="openai",
            api_key="secret",
            base_url=None,
            model_name="bad\nmodel",
        )
